function [e_opt,obj_e] = Generate_beamforming_e(N, M, K, G_tilde, z, W, e_ini, noise, power)

%%  Generate the parameters  %%%%%
A = zeros(size(G_tilde,2),size(G_tilde,2));
a = zeros(size(G_tilde,2),1);
for k = 1 : K
    A = A + abs( z(k) )^2 * G_tilde(:,:,k)' * W * W' * G_tilde(:,:,k);
    a = a + ( z(k) * W(:,k).' * conj( G_tilde(:,:,k) ) )';
end
e_tilde = [e_ini;1];
grad_f = ( A.' * e_tilde - a );
ka     = 10;
p=1000;
grad_G = norm(e_tilde,p)^(1-p) / ( 2 * ka ) / ( 1 - norm(e_tilde,p) ) ...
         * (e_tilde .* abs(e_tilde).^(p-2)) + grad_f;
d_gd   = - grad_G;
d_p    = d_gd - ( e_tilde' * d_gd ) / norm(e_tilde,2)^2 * e_tilde;
temp   = sqrt(M+1) * d_p / norm(d_p,2)^2;
a_opt  = ( e_tilde' * A.' * e_tilde - temp' * A.' * e_tilde - e_tilde' * a + temp' * a ) ...
       / ( e_tilde' * A.' * e_tilde - e_tilde' * A.' * temp - temp' * A.' * e_tilde + temp' * A.' * temp );
e      = (1-a_opt) * e_tilde + a_opt * sqrt(M+1) * d_p / norm(d_p,2)^2;
e_opt  = exp( 1i * angle( e(1:M) / e(M+1) ) );
ee    = [ e_opt; 1 ];
obj_e = ee' * A.' * ee - 2 * real( a' * ee ) + noise * z' * z + K;
end