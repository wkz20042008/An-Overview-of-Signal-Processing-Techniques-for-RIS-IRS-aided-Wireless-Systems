function [rate_sur] = Generate_rate_sur(const,C,B,X,G,K)

for g=1:G
    for k=1:K
        rate_sur(k,g)=const(k,g)+2*real(trace(C(:,:,k,g)'*X))-trace(X'*B(:,:,k,g)*X);
    end
end

end