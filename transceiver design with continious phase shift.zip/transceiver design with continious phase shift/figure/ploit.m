clc
clear all;
close all

load( 'Rate1'); Rate1=Rate;
load( 'Rate2'); Rate2=Rate;
load( 'Rate3'); Rate3=Rate;
load( 'Rate4'); Rate4=Rate;
load( 'Rate5'); Rate5=Rate;
load( 'Rate6'); Rate6=Rate;
load( 'Rate7'); Rate7=Rate;
load( 'Rate8'); Rate8=Rate;
load( 'Rate9'); Rate9=Rate;
load( 'Rate10'); Rate10=Rate;
load( 'Rate11'); Rate11=Rate;
load( 'Rate12'); Rate12=Rate;
load( 'Rate_time13'); Rate13=Rate(10);
CPU_Time13=time(10);

load( 'CPU_Time1'); CPU_Time1=CPU_Time;
load( 'CPU_Time2'); CPU_Time2=CPU_Time;
load( 'CPU_Time3'); CPU_Time3=CPU_Time;
load( 'CPU_Time4'); CPU_Time4=CPU_Time;
load( 'CPU_Time5'); CPU_Time5=CPU_Time;
load( 'CPU_Time6'); CPU_Time6=CPU_Time;
load( 'CPU_Time7'); CPU_Time7=CPU_Time;
load( 'CPU_Time8'); CPU_Time8=CPU_Time;
load( 'CPU_Time9'); CPU_Time9=CPU_Time;
load( 'CPU_Time10'); CPU_Time10=CPU_Time;
load( 'CPU_Time11'); CPU_Time11=CPU_Time;
load( 'CPU_Time12'); CPU_Time12=CPU_Time;

%% bar Figure
T               = [10:10:100];
X=T;
figure(1)
y1=[mean(Rate1(:,10),1); mean(Rate2(:,10),1); ...
   mean(Rate3,1);        mean(Rate4,1); ...
   mean(Rate5(:,10),1);  mean(Rate6(1:24,10),1); ...
   mean(Rate7(:,10),1);  mean(Rate8,1); ...
   mean(Rate9(:,10),1);  mean(Rate10,1); ...
   mean(Rate11,1);       mean(Rate12,1); ...
   Rate13]; 

y2=[mean(CPU_Time1(:,10),1); mean(CPU_Time2(:,10),1); ...
   mean(CPU_Time3,1);        mean(CPU_Time4,1); ...
   mean(CPU_Time5(:,10),1);  mean(CPU_Time6(:,10),1); ...
   mean(CPU_Time7(:,10),1);  mean(CPU_Time8,1); ...
   mean(CPU_Time9(:,10),1);  mean(CPU_Time10,1); ...
   mean(CPU_Time11,1);       mean(CPU_Time12,1); ...
   CPU_Time13]; 

yyaxis left;
b=bar(y1);
grid on;
ch = get(b,'children');
set(gca,'XTickLabel',{'1','2','3','4','5','6','7','8','9','10','11','12','13'});
set(ch,'FaceVertexCData',[1 0 1;0 0 0;]);
xlabel('Different algorithms');
ylabel('Sum rate (bps/Hz)');

yyaxis right;
b=bar(y2);
ylim([10,26000])
grid on;
ch = get(b,'children');
set(gca,'XTickLabel',{'1','2','3','4','5','6','7','8','9','10','11','12','13'});
% set(ch,'FaceVertexCData',[1 0 1;0 0 0;]);
xlabel('Different algorithms');
ylabel('CPU time (sec)');




%% Figure
T               = [10:10:100];
X=T;
figure(1)
semilogy(X,mean(Rate1,1)); hold on;
semilogy(X,mean(Rate2,1)); hold on;
semilogy(X,mean(Rate3,1)); hold on;
semilogy(X,mean(Rate4,1)); hold on;
semilogy(X,mean(Rate5,1)); hold on;
semilogy(X,mean(Rate6,1)); hold on;
semilogy(X,mean(Rate7,1)); hold on;
semilogy(X,mean(Rate8,1)); hold on;
semilogy(X,mean(Rate9,1)); hold on;
semilogy(X,mean(Rate10,1)); hold on;
semilogy(X,mean(Rate11,1)); hold on;

xlabel('Number of RIS elements: $$M$$', 'Interpreter', 'latex');
ylabel('Sum rate')
legend('Relaxation and projection', ...
       'SDR', ...
       'MM', ...
       'Manifold optimization', ...
       'BCD', ...       
       'Rank-one equivalents', ...
       'ADMM', ...
       'CCP', ...  
       'Barrier function penalty', ...
       'Accelerated projected gradient', ...
       'Gradient descent approach', ...
       'Interpreter', 'latex')
grid on;