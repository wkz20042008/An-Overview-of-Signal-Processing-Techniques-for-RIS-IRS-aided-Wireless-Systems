function [e_opt,obj_e,flag] = Generate_beamforming_e(N, M, K, G_tilde, z, W, e, noise, power)

%%  Generate the parameters  %%%%%
A = zeros(size(G_tilde,2),size(G_tilde,2));
a = zeros(size(G_tilde,2),1);
for k = 1 : K
    A = A + abs( z(k) )^2 * G_tilde(:,:,k)' * W * W' * G_tilde(:,:,k);
    a = a + ( z(k) * W(:,k).' * conj( G_tilde(:,:,k) ) )';
end

%%  Generate the optimal objective value
R=[A.'  -a;  -a'  0];

cvx_solver mosek
cvx_save_prefs

cvx_begin quiet
    variable X(M+2,M+2) hermitian
    
    minimize real(trace(R*X))
  
    subject to
             X == hermitian_semidefinite(M+2);
             diag(X) == 1;             
cvx_end

if cvx_status(1)=='S'  ||  cvx_status(3)=='a'
   flag  = 1;
   
   [t1,t2]=eig(X);
    location=find( abs(diag(t2))>10^(-6));
    if size(location,1)==1
        e_hat=t1(:,location)*t2(location,location)^(1/2);
    else
        for i=1:1000
            flag_2=1;
            b1(:,i)=t1*t2^(1/2)*sqrt(1/2)*(randn(M+2,1) + sqrt(-1)*  randn(M+2,1));
            b2(:,i)=exp(1j*angle(b1(:,i)/b1(M+2,i)));
            b2(M+1,i)=1;
            %%%%%  Obj value  %%%%%
          
            Obj(i)=b2(:,i)'*R*b2(:,i)+ noise * z' * z + K;
      
            if Obj(i)<=0
               Obj(i)=100;
            end    
        end
        [X,location]=min(Obj);
        e_hat=b2(:,location);
    end
    e_opt=exp(1j*angle(e_hat(1:M)/e_hat(M+1)));
   

   ee    = [ e_opt; 1 ];
   obj_e = ee' * A.' * ee - 2 * real( a' * ee ) + noise * z' * z + K;
   
   sum=0;
   for k=1:K
       sum = sum + z(k)*z(k)'*(G_tilde(:,:,k) *conj(ee))'* W * W' *(G_tilde(:,:,k) *conj(ee)) ...
             -2*real( z(k)*(G_tilde(:,:,k) *conj(ee))'* W(:,k) ) + noise * z(k)' * z(k)+1;
   end
else
   flag  = 0;
   e_opt = ones(M,1);
   obj_e = 0;
end

                            

end