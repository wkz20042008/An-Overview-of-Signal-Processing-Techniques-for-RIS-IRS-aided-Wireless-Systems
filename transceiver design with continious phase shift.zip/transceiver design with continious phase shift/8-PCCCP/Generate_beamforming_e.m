function [e_opt,obj_e,flag] = Generate_beamforming_e(N, M, K, G_tilde, z, W, e_ini, noise, power,n)

%%  Generate the parameters  %%%%%
A = zeros(size(G_tilde,2),size(G_tilde,2));
a = zeros(size(G_tilde,2),1);
for k = 1 : K
    A = A + abs( z(k) )^2 * G_tilde(:,:,k)' * W * W' * G_tilde(:,:,k);
    a = a + ( z(k) * W(:,k).' * conj( G_tilde(:,:,k) ) )';
end
                 
e_total(:,1) = [ e_ini; 1 ];
scaler=3;
step=2;
scaler_max=max(200-n*20,30);
for n_outter=1:10
    scaler  = 5;
    e_inner = sqrt(1/2)*(randn(M,1)+sqrt(-1)*randn(M,1));
    e_inner = exp(1j.*angle(e_inner));
    e_inner = [ e_ini; 1 ];
for temp=1:3
    
%     cvx_solver mosek
%     cvx_save_prefs

    cvx_begin quiet
        variable e(M+1,1) complex
        variable epselo(2*M)

        [t1,t2]=eig(A);
        temp1=e'*t1*sqrt(t2);

        minimize (temp1*temp1'-2*real(a'*e) + 1*sum(epselo) )

        subject to

             for m=1:M
                 norm(e(m),2)<=sqrt(1+epselo(m));
                 e_inner(m)'*e_inner(m)-2*real(e_inner(m)'*e(m))<=epselo(M+m)-1;
             end
             epselo >= 0;
             e(M+1) == 1;

    cvx_end
    
    if cvx_status(1)=='S' || cvx_status(3)=='a'
        e_inner = e;        
        obj(temp+1) = (temp1*temp1'-2*real(a'*e) + scaler*sum(epselo) );
        e_total(:,temp+1)=e;
        test_1(temp)=norm(e_total(:,temp+1)-e_total(:,temp),2)^2;
        test_2(temp)=sum(epselo);
        if test_2(temp)<=0.001
           aS = [ scaler, scaler_max ];
        else
           aS = [ scaler + step, scaler_max ];
        end
        scaler=min(aS);

    
        if test_1(temp)<=0.001 && test_2(temp)<=0.001 && abs(obj(temp+1)-obj(temp))<=0.001
            break;
        end
    end
end
if temp<50
    break;
end

end

if cvx_status(1)=='S' ||  cvx_status(3)=='a'
   flag=1;
   e_opt = exp( 1i * angle( e(1:M) / e(M+1) ) );
   ee    = [ e_opt; 1 ];
   obj_e = ee' * A.' * ee - 2 * real( a' * ee ) + noise * z' * z + K;
  

else
    flag=0;
end
end