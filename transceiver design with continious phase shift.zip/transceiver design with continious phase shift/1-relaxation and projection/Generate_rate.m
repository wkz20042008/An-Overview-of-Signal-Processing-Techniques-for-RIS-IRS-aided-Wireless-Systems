function [rate]=Generate_rate(N, M, G, K, H, F, e, noise_maxpower, trans_maxpower,miu)

rate=0;
for g=1:G
    for k=1:K
        temp=F(:,g)'*H(:,:,k,g)'*e;
        r(k,g)=e'*H(:,:,k,g)*F*F'*H(:,:,k,g)'*e+noise_maxpower;
        r_g(k,g)=r(k,g)-temp'*temp;
        rate_ini(k,g)=log2(1+temp'*temp/r_g(k,g));
    end
    rate=rate+real(min(rate_ini(:,g))) ;
end
   

end 