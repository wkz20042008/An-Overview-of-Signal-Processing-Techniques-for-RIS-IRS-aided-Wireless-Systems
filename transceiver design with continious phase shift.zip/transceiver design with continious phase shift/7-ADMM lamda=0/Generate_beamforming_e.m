function [e_opt,obj_opt,omiga_opt,lamb_opt] = Generate_beamforming_e(N, M, K, G_tilde, z, W, e_ini, noise, power,omiga_ini,lamb_ini)

%%  Generate the parameters  %%%%%
A = zeros(size(G_tilde,2),size(G_tilde,2));
a = zeros(size(G_tilde,2),1);
for k = 1 : K
    A = A + abs( z(k) )^2 * G_tilde(:,:,k)' * W * W' * G_tilde(:,:,k);
    a = a + ( z(k) * W(:,k).' * conj( G_tilde(:,:,k) ) )';
end

e(:,1)= [e_ini;1];
eta   = norm(A.','fro')^2;
for i=1:1
    e(:,i+1) = inv( A.' + eta / 2 * eye(M+1) ) * ( a + eta / 2 * ( omiga_ini - lamb_ini ) );

    omiga_opt    = exp(1j*angle(e(:,i) + lamb_ini)); 
    omiga_opt = exp(1j*angle(  omiga_opt/omiga_opt(M+1) )); 

    lamb_opt =  (e(:,i+1) - omiga_opt)*0 ;

    ee         = e(:,i+1);
    obj_e(i+1) = ee' * A.' * ee - 2 * real( a' * ee ) + noise * z' * z + K ...
               + eta / 2 * norm(lamb_opt + ee - omiga_opt,2)^2;
    if  abs( obj_e(i+1)-obj_e(i) ) < 10^(-5)
        break;
    end
    
end
 
   e_opt      = e(1:M,i+1);
%    e_opt = [];  e_opt      = omiga_opt(1:M);
   ee         = [];
   ee         = [e_opt; 1];
   obj_opt    = ee' * A.' * ee - 2 * real( a' * ee ) + noise * z' * z + K ;
   obj_opt    = obj_e(i+1);
end