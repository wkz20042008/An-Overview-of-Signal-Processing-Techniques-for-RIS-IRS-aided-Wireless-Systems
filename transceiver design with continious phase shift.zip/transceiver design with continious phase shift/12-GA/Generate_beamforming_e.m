function [e_opt,obj_e] = Generate_beamforming_e(N, M, K, G_tilde, z, W, e_ini, noise, power)

%%  Generate the parameters  %%%%%
A = zeros(size(G_tilde,2),size(G_tilde,2));
a = zeros(size(G_tilde,2),1);
for k = 1 : K
    A = A + abs( z(k) )^2 * G_tilde(:,:,k)' * W * W' * G_tilde(:,:,k);
    a = a + ( z(k) * W(:,k).' * conj( G_tilde(:,:,k) ) )';
end
[ t1, t2 ] = eig(A.');


t = ( max( diag( t2 ) ) * eye(M+1) - A.' )*[ e_ini; 1 ] + a;
e_opt = exp( 1j * angle( t(1:M) / t(M+1) ) );
ee    = [ e_opt; 1 ];
obj_e = ee' * A.' * ee - 2 * real( a' * ee ) + noise * z' * z + K;

%%%%  Acceleration  %%%%%
% e(:,1)=e_ini;
% for i=1:2
%     t = ( max( diag( t2 ) ) * eye(M+1) - A.' )*[ e(:,i); 1 ] + a;
%     e(:,i+1) = exp( 1j * angle( t(1:M) / t(M+1) ) );
%     ee    = [ e(:,i+1); 1 ];
%     obj(i+1) = ee' * A.' * ee - 2 * real( a' * ee ) + noise * z' * z + K;
%     delta_e(:,i) = e(:,i+1) - e(:,i);
% end
% ro = - norm(delta_e(:,1),2) / norm(delta_e(:,2),2);
% e_opt = exp( 1j * angle( e(:,1) - 2 * ro * delta_e(:,1) + ro^2 * delta_e(:,2) )  );
% ee    = [ e_opt; 1 ];
% obj_e = ee' * A.' * ee - 2 * real( a' * ee ) + noise * z' * z + K;
% while obj_e>obj(2)
%     ro=(ro-1)/2;
%     e_opt = exp( 1j * angle( e(:,1) - 2 * ro * delta_e(:,1) + ro^2 * delta_e(:,2) )  );
%     ee    = [ e_opt; 1 ];
%     obj_e  = ee' * A.' * ee - 2 * real( a' * ee ) + noise * z' * z + K;
%     if ro == -1
%         break;
%     end
% end


end