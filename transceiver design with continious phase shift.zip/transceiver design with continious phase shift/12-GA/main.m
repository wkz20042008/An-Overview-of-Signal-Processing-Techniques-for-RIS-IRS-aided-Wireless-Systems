%By Zhou Gui
%From 2019-2-14 to 
% close all;
clear all;clc;
warning('off');
rand('twister',mod(floor(now*8640000),2^31-1));


global G_large G_tilde  noise K M power
%% Parameters Initialization %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% '1' stands for source-relays; '2' stands for relays-destination
N          = 10;            % array number of BS
M_all      = 100;            % array number of IRS
K          = 4;            % number of users in each group

SNR        = 5;     % dBm
noise      = 1; % W
power      = 10^(SNR/10)*noise;


%% Simulation loop %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
num_loop = 100; 
for loop = 1 : num_loop
    outerflag=1; 
for m = 1 : length(M_all)
    t0 = cputime;
    M  = M_all(m);
    %%%%%  Generate channel  %%%%%
    H   = (1/sqrt(2)) * ( randn(N,M) + 1i*randn(N,M) );
    H   = H / norm( H, 'fro' ) * sqrt( N * M );
    h_r = (1/sqrt(2)) * ( randn(M,K) + 1i*randn(M,K) );
    h_r = h_r / norm( h_r, 'fro' ) * sqrt( K * M );
    h_d = (1/sqrt(2)) * ( randn(N,K) + 1i*randn(N,K) );
    h_d = h_d / norm( h_d, 'fro' ) * sqrt( K * M );
    G=[];  G_tilde=[]; G_large=[];
    for k=1:K
        G(:,:,k)       = H * diag(h_r(:,k));
        G_tilde(:,:,k) = [G(:,:,k) h_d(:,k)];
        G_large        = [G_large G_tilde(:,:,k)];
    end

       
       
       %%%%%  Optimize e  %%%%%
        
        fun = @Generate_beamforming_e_GA; 
        nvars=M;   
        LB=zeros(1,M);
        UP=2*pi*ones(1,M);
        [phi_best,fval]=ga(fun,nvars,[],[],[],[],LB,UP);

        e_opt = exp(1i*phi_best);
         

    Rate(loop,m)=real(-fval);

    t2=cputime;
    CPU_Time(loop,m)=t2-t0;
    loop
end
    save('Rate','Rate');
    save('CPU_Time','CPU_Time');
end
a=1;

xlabel=M_all;
ylabel=Rate;
plot(xlabel,ylabel,'-o');
hold on ; 
grid on
    
