function [e_opt,obj_e] = Generate_beamforming_e(N, M, K, G_tilde, z, W, e_ini, noise, power)

%%  Generate the parameters  %%%%%
A = zeros(size(G_tilde,2),size(G_tilde,2));
a = zeros(size(G_tilde,2),1);
for k = 1 : K
    A = A + abs( z(k) )^2 * G_tilde(:,:,k)' * W * W' * G_tilde(:,:,k);
    a = a + ( z(k) * W(:,k).' * conj( G_tilde(:,:,k) ) )';
end
e_tilde  = [e_ini;1];
grad_euc = - ( A.' * e_tilde - a );
grad_Rie = grad_euc - real( conj( grad_euc ) .* e_tilde ) .* e_tilde;
beta = 100;
e_tang   = e_tilde + beta * grad_Rie;
e_opt    = e_tang(1:M) ./ abs(e_tang(1:M));
ee    = [ e_opt; 1 ];
obj_e = ee' * A.' * ee - 2 * real( a' * ee ) + noise * z' * z + K;
end