function [D] = Generate_D(const,C,B,X,G,K)

for g=1:G
    for k=1:K
        rate_sur(k,g)=const(k,g)+2*real(trace(C(:,:,k,g)'*X))-trace(X'*B(:,:,k,g)*X);
    end
end
D=zeros(size(X,1),size(X,2),G);
for g=1:G
    g_fun(:,g)=exp(-miu*rate_sur(:,g))/sum(exp(-miu*rate_sur(:,g)));
    for k=1:K
        D(:,:,g)=D(:,:,g)+g_fun(k,g)*( C(:,:,k,g)- B(:,:,k,g)'*X);
    end
end
end