function result = Generate_beamforming_e_GA(phi)

global G_large G_tilde  noise K M power

phi     = phi.';
e_j_phi = exp(1i*phi);
ee      = [ e_j_phi; 1 ];
Q       = G_large * kron( eye(K), conj(ee) );
W       = Q * inv( Q' * Q ) ;
p       = norm(W,'fro');
F       = W / p * sqrt(power);

rate=0;
for k=1:K
    temp = F(:,k)' * G_tilde(:,:,k) * conj( ee );
    r(k) = ee.' * G_tilde(:,:,k)' * F * F' * G_tilde(:,:,k) * conj( ee ) + noise;
    r_g(k) = r(k) - temp' * temp;
    rate = rate + log2( 1 + temp'*temp / r_g(k) );
end

result = real(-1*rate);


end