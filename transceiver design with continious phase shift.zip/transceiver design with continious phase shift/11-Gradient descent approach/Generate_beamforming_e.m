function [e_opt,obj_e] = Generate_beamforming_e(N, M, K, G_tilde, z, W, e_ini, noise, power)

%%  Generate the parameters  %%%%%
A = zeros(size(G_tilde,2),size(G_tilde,2));
a = zeros(size(G_tilde,2),1);
for k = 1 : K
    A = A + abs( z(k) )^2 * G_tilde(:,:,k)' * W * W' * G_tilde(:,:,k);
    a = a + ( z(k) * W(:,k).' * conj( G_tilde(:,:,k) ) )';
end
e_tilde = [e_ini;1];
grad_f = ( A.' * e_tilde - a );
step_size=20;
e      = e_tilde - step_size*grad_f;
e_opt  = exp( 1i * angle( e(1:M) / e(M+1) ) );
ee    = [ e_opt; 1 ];
obj_e = ee' * A.' * ee - 2 * real( a' * ee ) + noise * z' * z + K;
end