function [e_opt,obj_e] = Generate_beamforming_e(N, M, K, G_tilde, z, W, e_ini, noise, power)

%%  Generate the parameters  %%%%%
A = zeros(size(G_tilde,2),size(G_tilde,2));
a = zeros(size(G_tilde,2),1);
for k = 1 : K
    A = A + abs( z(k) )^2 * G_tilde(:,:,k)' * W * W' * G_tilde(:,:,k);
    a = a + ( z(k) * W(:,k).' * conj( G_tilde(:,:,k) ) )';
end

e=[e_ini;1];
for m = 1 : M 
    t = ( a(m)-A(:,m).' * e + A(m,m) * e(m) ) / A(m,m);
    e(m) = exp( 1j * angle( t ) );
end
e_opt = e(1:M);
ee    = [ e_opt; 1 ];
obj_e = ee' * A.' * ee - 2 * real( a' * ee ) + noise * z' * z + K;
end