close all;
clear all;clc;
warning('off');
rand('twister',mod(floor(now*8640000),2^31-1));

N          = 10;            % array number of BS
M_all      = 10:10:100;            % array number of IRS
K          = 4;            % number of users in each group

SNR        = 5;     % dBm
noise      = 1; % W
power      = 10^(SNR/10)*noise;


%% Simulation loop %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
num_loop = 1000; 
for loop = 1 : num_loop
    outerflag=1; 
    for m = 1 : length(M_all)
        t0 = cputime;
        M  = M_all(m);
        %%%%%  Generate channel  %%%%%
        H   = (1/sqrt(2)) * ( randn(N,M) + 1i*randn(N,M) );
        H   = H / norm( H, 'fro' ) * sqrt( N * M );
        h_r = (1/sqrt(2)) * ( randn(M,K) + 1i*randn(M,K) );
        h_r = h_r / norm( h_r, 'fro' ) * sqrt( K * M );
        h_d = (1/sqrt(2)) * ( randn(N,K) + 1i*randn(N,K) );
        h_d = h_d / norm( h_d, 'fro' ) * sqrt( K * M );
        G_all=[];  G_tilde_all=[];
        for k=1:K
            G_all(:,:,k,m,loop)       = H * diag(h_r(:,k));
            G_tilde_all(:,:,k,m,loop) = [G_all(:,:,k,m,loop) h_d(:,k)];
        end
    end
end
save('G_all','G_all');
save('G_tilde_all','G_tilde_all');