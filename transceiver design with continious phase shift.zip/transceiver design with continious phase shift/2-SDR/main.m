%By Zhou Gui
%From 2019-2-14 to 
close all;
clear all;clc;
warning('off');
rand('twister',mod(floor(now*8640000),2^31-1));
%% Parameters Initialization %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% '1' stands for source-relays; '2' stands for relays-destination
N          = 10;            % array number of BS
M_all      = 10:10:100;            % array number of IRS
K          = 4;            % number of users in each group

SNR        = 5;     % dBm
noise      = 1; % W
power      = 10^(SNR/10)*noise;


%% Simulation loop %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
num_loop = 1000; 
for loop = 1 : num_loop
    outerflag=1; 
for m = 1 : length(M_all)
    t0 = cputime;
    M  = M_all(m);
    %%%%%  Generate channel  %%%%%
    H   = (1/sqrt(2)) * ( randn(N,M) + 1i*randn(N,M) );
    H   = H / norm( H, 'fro' ) * sqrt( N * M );
    h_r = (1/sqrt(2)) * ( randn(M,K) + 1i*randn(M,K) );
    h_r = h_r / norm( h_r, 'fro' ) * sqrt( K * M );
    h_d = (1/sqrt(2)) * ( randn(N,K) + 1i*randn(N,K) );
    h_d = h_d / norm( h_d, 'fro' ) * sqrt( K * M );
    G=[];  G_tilde=[];
    for k=1:K
        G(:,:,k)       = H * diag(h_r(:,k));
        G_tilde(:,:,k) = [G(:,:,k) h_d(:,k)];
    end

    %%%%%  Initialization  %%%%% 
    e_ini = [];  e_ini    = ones(M,1);
%     e_ini = [];  e_ini    = exp(1j*angle((1/sqrt(2)) * ( randn(M,1) + 1i*randn(M,1) )));
    W_ini = [];  W_ini    = ones(N,K)*sqrt(power/(N*K)); 
    W     = [];  W(:,:,1) = W_ini;
    e     = [];  e(:,1)   = e_ini;
    
    num_iterative = 10000;
    for n  = 1 : num_iterative
       %%%%%  Optimize a  %%%%%
       for k=1:K
           gk(:,k) = G_tilde(:,:,k)*[ conj(e(:,n)); 1];
           z(k,1)  = W(:,k,n)' * gk(:,k) / ( gk(:,k)'*W(:,:,n)*W(:,:,n)'*gk(:,k) + noise );
       end
       
       %%%%%  Optimize W  %%%%%
       P   = gk*diag(z');
       F_0 = inv(P*P')*P;
       if norm(F_0,'fro')^2 <= power
          F = F_0;
       else
          lambda_max = 20;
          lambda_min = 0;
          while   (lambda_max-lambda_min) > 10^(-5)
              lambda     = ( lambda_max + lambda_min ) / 2;
              F = inv(P*P' + lambda*eye(N))*P;
              if norm(F,'fro')^2 > power 
                 lambda_min = lambda;
              else if norm(F,'fro')^2 < power 
                      lambda_max = lambda;
                  end
              end
          end
       end
       W(:,:,n+1) = F;
       
       
       %%%%%  Optimize e  %%%%%
        [e_opt,obj,flag] = Generate_beamforming_e(N, M, ...
                        K, G_tilde, z, W(:,:,n+1), e(:,n), noise, power);
        obj_e(n+1)=obj;
        e(:,n+1)=e_opt;
        if flag==0
            outerflag=0;
            break;
        end    
        
        
        %%%%%  stop criterion  %%%%%
        if abs(obj_e(n+1)-obj_e(n))<10^(-7)
            break;
        end
        x=[loop,m,n]
    end
     if outerflag==0
        break;
     end     
    
     
    %%%%%  Generate rate  %%%%%
    F = W(:,:,n+1);
    e_tilde = [ e(:,n+1); 1 ];
    rate=0;
    for k=1:K
        temp = F(:,k)' * G_tilde(:,:,k) * conj( e_tilde );
        r(k) = e_tilde.' *G_tilde(:,:,k)' * F * F' * G_tilde(:,:,k) * conj( e_tilde ) + noise;
        r_g(k) = r(k) - temp' * temp;
        rate = rate + log2( 1 + temp'*temp / r_g(k) );
    end
    Rate(loop,m)=real(rate);

    t2=cputime;
    CPU_Time(loop,m)=t2-t0;
end
    save('Rate','Rate');
    save('CPU_Time','CPU_Time');
end
a=1;
    
