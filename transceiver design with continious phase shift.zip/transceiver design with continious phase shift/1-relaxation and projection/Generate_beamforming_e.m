function [e_opt,obj_e,flag] = Generate_beamforming_e(N, M, K, G_tilde, z, W, e, noise, power)

%%  Generate the parameters  %%%%%
A = zeros(size(G_tilde,2),size(G_tilde,2));
a = zeros(size(G_tilde,2),1);
for k = 1 : K
    A = A + abs( z(k) )^2 * G_tilde(:,:,k)' * W * W' * G_tilde(:,:,k);
    a = a + ( z(k) * W(:,k).' * conj( G_tilde(:,:,k) ) )';
end

%%  Generate the optimal objective value
cvx_solver mosek
cvx_save_prefs

cvx_begin quiet
    variable e(M+1,1) complex
    expression   constraints;
    
    I=eye(M+1);
    for m=1:M
        constraints(m)=e'*diag(I(:,m))*e-1;
    end
    temp=e(M+1)-1;
    constraints(M+1)=norm(temp,2);
    
    [t1,t2]=eig(A);
    temp1=e'*t1*sqrt(t2);
    
    minimize (temp1*temp1'-2*real(a'*e))
  
    subject to
         constraints<=zeros(1,M+1);
                
cvx_end

if cvx_status(1)=='S'  ||  cvx_status(3)=='a'
   flag  = 1;
   e_opt = exp( 1i * angle( e(1:M) / e(M+1) ) );
   ee    = [ e_opt; 1 ];
   obj_e = ee' * A.' * ee - 2 * real( a' * ee ) + noise * z' * z + K;
   
   sum=0;
   for k=1:K
       sum = sum + z(k)*z(k)'*(G_tilde(:,:,k) *conj(ee))'* W * W' *(G_tilde(:,:,k) *conj(ee)) ...
             -2*real( z(k)*(G_tilde(:,:,k) *conj(ee))'* W(:,k) ) + noise * z(k)' * z(k)+1;
   end
else
   flag  = 0;
   e_opt = ones(M,1);
   obj_e = 0;
end

                            

end